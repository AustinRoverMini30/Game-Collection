<footer>
    <p>Game Collection - 2024 - Tous droits réservés</p>
</footer>